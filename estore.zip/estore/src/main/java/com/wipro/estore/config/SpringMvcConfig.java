package com.wipro.estore.config;

public class SpringMvcConfig {

}
