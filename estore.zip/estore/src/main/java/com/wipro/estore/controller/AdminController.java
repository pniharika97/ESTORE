package com.wipro.estore.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.wipro.estore.dao.ProductRepository;
import com.wipro.estore.dao.RegisterRepository;
import com.wipro.estore.model.Product;
import com.wipro.estore.model.Register;

@Controller
public class AdminController {

	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	RegisterRepository registerRepository;
	

	@RequestMapping(value = "/addVideo",method=RequestMethod.GET)
	public String addVideoPage(ModelMap model,@ModelAttribute("product") Product product) {
		model.addAttribute("product", new Product());
		return "AddVideo";
	}
	
	@PostMapping(value = "/addVideo",produces="text/html")
	public String addVideoFromPage(ModelMap model,@Valid Product product,BindingResult result,RedirectAttributes attributes) {
		if(result.hasErrors())
		{
			return "AddVideo";
		}
	int producttmp =	productRepository.findProductCount(product.getName());
	System.out.println("In admin"+product.getName()+" product name :"+product.getName());
	if(producttmp > 0)
	{
		model.addAttribute("error","InvalidData");
		return "AddVideo";
	}
	productRepository.saveAndFlush(product);
		return "redirect:adminhome";
	}
	@RequestMapping(value = "/deleteProduct",method=RequestMethod.GET)
	public String deleteProduct(ModelMap model,@RequestParam("d") long id) {
		productRepository.deleteById(id);
	return "redirect:adminhome";
	}
	
	@RequestMapping(value = "/adminhome",method=RequestMethod.GET)
	public String showHomePage(ModelMap model) {
		
		List<Product> list=productRepository.findAll();
		if(list.isEmpty())
		{
			model.addAttribute("message", "No videos to display");
			return "ManageVideos";
		}
		model.addAttribute("Orders", list);
		return "ManageVideos";
	}
}
