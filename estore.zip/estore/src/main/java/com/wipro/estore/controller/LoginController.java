package com.wipro.estore.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.wipro.estore.dao.RegisterRepository;
import com.wipro.estore.model.Register;

@Controller	
@SessionAttributes("user")
public class LoginController {

	@Autowired
	RegisterRepository registerRepository;
	
	@RequestMapping(value = "/login",method=RequestMethod.GET)
	public String showLoginPage(ModelMap model) {
		return "Login";
	}
	
	@PostMapping(value = "/login",produces="text/html")
	public String validateLoginPage(ModelMap model,@RequestParam("userId") String username,@RequestParam("password") String password,RedirectAttributes redirectAttrs) {
//System.out.println("Username"+username+" and Password is"+password);
if (username.equals("admin") && password.equals("admin@123")) {
	return "redirect:/adminhome";
}
else {
Optional<Register> register =	registerRepository.findById(username);
if(register.isPresent()) {
if(username.equals(register.get().getUserName()) && password.equals(register.get().getPassword())) {
	model.put("user", username);
	//System.out.println("In login controller :"+model.getAttribute("user"));
	return "redirect:/userhome";}}
model.addAttribute("error","Invalid Credentials");
return "Login";
} }
	
}
