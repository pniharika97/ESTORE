package com.wipro.estore.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.wipro.estore.dao.AddCartBeanRepository;
import com.wipro.estore.dao.CreateOrderRepository;
import com.wipro.estore.dao.InvoiceBeanRepository;
import com.wipro.estore.dao.ProductRepository;
import com.wipro.estore.dao.RegisterRepository;
import com.wipro.estore.model.AddCartBean;
import com.wipro.estore.model.CreateOrder;
import com.wipro.estore.model.InvoiceBean;
import com.wipro.estore.model.InvoiceGenerator;
import com.wipro.estore.model.Product;
import com.wipro.estore.model.Register;

@Controller
@SessionAttributes({ "videoscount", "videosprice", "user" })
public class UserController {

	@Autowired
	AddCartBeanRepository addCartBeanRepository;

	static int videoscount = 0;
	static double videosprice = 0.0;
	double tmp = 0;

	@ModelAttribute("videoscount")
	public int videosCount() {
		return videoscount;
	}

	@ModelAttribute("videosprice")
	public double videosPrice() {
		return videosprice;
	}

	@Autowired
	CreateOrderRepository createOrderRepository;

	@Autowired
	RegisterRepository registerRepository;

	@Autowired
	ProductRepository productRepository;

	@Autowired
	InvoiceBeanRepository invoiceBeanRepository;

	@RequestMapping(value = "/userhome", method = RequestMethod.GET)
	public String showHomePage(ModelMap model) {

		// System.out.println("In home page username : " + model.getAttribute("user"));

		List<Product> list = productRepository.findAll();
		if (list.isEmpty()) {
			model.addAttribute("message", "No videos to display");
			return "UserHome";
		}
		model.addAttribute("lists", list);
		return "UserHome";
	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String showRegisterPage(ModelMap model, @ModelAttribute("register") Register register) {
		model.addAttribute("register", new Register());
		return "Register";
	}

	@PostMapping(value = "/register", produces = "text/html")
	public String RegisterUserPage(ModelMap model, @Valid Register register, BindingResult result,
			RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return "Register";
		}
		boolean flag = registerRepository.existsById(register.getUserName());
		boolean flag1 = (register.getPassword().equals(register.getConfirmPassword()));
		// System.out.println("Registration user " + register.getUserName() + " " +
		// register.getPassword() + " "
		// + register.getEmail() + " " + register.getConfirmPassword());
		if (flag || flag1 == false) {
			model.addAttribute("error", "InvalidData");
			return "Register";
		}
		model.put("user", register.getUserName());
		registerRepository.saveAndFlush(register);
		return "redirect:login";
	}

	@RequestMapping(value = "/addItems/{ProductName}", method = RequestMethod.GET)
	public String addItemsPage(ModelMap model, @PathVariable("ProductName") String ProductName) {
		++videoscount;
		int Quantity = 0;
		double subtotal = 0.0;
		Product pr = productRepository.findProductByName(ProductName);
		if (pr.getName().equals(ProductName)) {
			tmp = pr.getPrice();
		}
		AddCartBean adtmp = addCartBeanRepository.findInCartByProductName(ProductName);
		int rowscount = addCartBeanRepository.findProductCountInCart(ProductName);
		// System.out.println("In add items page" + ProductName);
		// System.out.println("In username " + model.getAttribute("user"));
		if (rowscount > 0) {
			AddCartBean addCartBean = new AddCartBean();
			Quantity = adtmp.getQuantity() + 1;
			subtotal = (pr.getPrice()) * Quantity;
			addCartBean.setName(pr.getName());
			addCartBean.setPrice(pr.getPrice());
			addCartBean.setQuantity(Quantity);
			addCartBean.setUsername(model.getAttribute("user").toString());
			addCartBean.setSubtotal(subtotal);
			// System.out.println("Addin item inside if block" + pr.getName());
			addCartBeanRepository.deleteById(adtmp.getId());
			addCartBeanRepository.save(addCartBean);
		} else {
			AddCartBean addCartBean = new AddCartBean();
			Quantity = 1;
			subtotal = pr.getPrice() * Quantity;
			addCartBean.setName(pr.getName());
			addCartBean.setPrice(pr.getPrice());
			addCartBean.setQuantity(Quantity);
			addCartBean.setUsername(model.getAttribute("user").toString());
			addCartBean.setSubtotal(subtotal);
			// System.out.println("Addin item inside else block" + pr.getName());
			addCartBeanRepository.save(addCartBean);
		}
		videosprice = videosprice + tmp;
		// System.out.println("video Price" + videosprice);
		model.addAttribute("videoscount", videoscount);
		model.addAttribute("videosprice", videosprice);
		return "redirect:/userhome";
	}

	@RequestMapping(value = "/myaccount", method = RequestMethod.GET)
	public String accountDetailsPage(ModelMap model) {
		model.addAttribute("videoscount", videoscount);
		model.addAttribute("videosprice", videosprice);
		Optional<Register> register = registerRepository.findById(model.getAttribute("user").toString());
		// System.out.println("Username " + register.get().getUserName());
		// System.out.println("email" + register.get().getEmail());
		model.addAttribute("userName", register.get().getUserName());
		model.addAttribute("email", register.get().getEmail());
		List<InvoiceBean> invoiceList = invoiceBeanRepository.findAll();
		List<InvoiceBean> tmplist = new ArrayList<InvoiceBean>();
		for (InvoiceBean b : invoiceList) {
			if (register.get().getUserName().equals(b.getUsername())) {
				tmplist.add(b);
			}
		}
		model.addAttribute("Orders", tmplist);
		return "MyAccount";
	}

	@RequestMapping(value = "/removeItems/{ProductName}", method = RequestMethod.GET)
	public String removeItemsFromPage(ModelMap model, @PathVariable("ProductName") String ProductName) {
		AddCartBean adcr = addCartBeanRepository.findInCartByProductName(ProductName);
		addCartBeanRepository.deleteById(adcr.getId());
		videosprice = videosprice - adcr.getSubtotal();
		videoscount = videoscount - adcr.getQuantity();
		model.addAttribute("videoscount", videoscount);
		model.addAttribute("videosprice", videosprice);
		return "redirect:/checkout";
	}

	@RequestMapping(value = "/checkout", method = RequestMethod.GET)
	public String checkoutPage(ModelMap model) {
		List<AddCartBean> addCartBeans = addCartBeanRepository.findAll();
		if (addCartBeans.isEmpty()) {
			model.addAttribute("message", "Cart is empty");
			return "CheckOut";
		}
		model.addAttribute("Orders", addCartBeans);
		model.addAttribute("videoscount", videoscount);
		model.addAttribute("videosprice", videosprice);
		return "CheckOut";
	}

	@RequestMapping(value = "/ordercreation", method = RequestMethod.GET)
	public String createOrdersPage(ModelMap model, @ModelAttribute("createOrder") CreateOrder createOrder) {
		model.addAttribute("videoscount", videoscount);
		model.addAttribute("videosprice", videosprice);
		model.addAttribute("createOrder", new CreateOrder());
		return "CreateOrder";
	}

	@RequestMapping(value = "/ordercreation", method = RequestMethod.POST)
	public String inputOrdersPage(ModelMap model, @Valid CreateOrder createOrder, BindingResult result) {
		if (result.hasErrors()) {
			return "CreateOrder";
		}
		createOrderRepository.saveAndFlush(createOrder);
		List<AddCartBean> adcrList = addCartBeanRepository.findAll();
		for (AddCartBean atmpbean : adcrList) {
			if (atmpbean.getUsername().equals(model.getAttribute("user").toString())) {
				InvoiceBean invoiceBean = new InvoiceBean();
				invoiceBean.setInvoiceId(InvoiceGenerator.getInvoice());
				invoiceBean.setUsername(model.getAttribute("user").toString());
				invoiceBean.setItemsPurchased(atmpbean.getQuantity());
				invoiceBean.setInvoicedAmount(atmpbean.getSubtotal());
				invoiceBeanRepository.saveAndFlush(invoiceBean);
			}
		}
		model.addAttribute("videoscount", videoscount);
		model.addAttribute("videosprice", videosprice);
		model.addAttribute("error", "Order placed successfully");
		videoscount = 0;
		videosprice = 0;
		return "CreateOrder";
	}

}