package com.wipro.estore.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.wipro.estore.model.AddCartBean;


@Repository
@Transactional
public interface AddCartBeanRepository extends JpaRepository<AddCartBean,Integer> {
	
	@Query("SELECT p FROM AddCartBean p WHERE p.name = ?1")
	AddCartBean findInCartByProductName(String name);
	
	@Query("SELECT count(p) FROM AddCartBean p WHERE p.name = ?1")
	int findProductCountInCart(String name);
	
}
