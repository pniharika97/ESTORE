package com.wipro.estore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wipro.estore.model.CreateOrder;

@Repository
public interface CreateOrderRepository extends JpaRepository<CreateOrder, Integer> {

}
