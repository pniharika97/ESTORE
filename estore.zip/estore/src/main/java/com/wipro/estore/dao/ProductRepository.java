package com.wipro.estore.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.wipro.estore.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
	@Query("SELECT count(p) FROM Product p WHERE p.name = ?1")
	int findProductCount(String name);
	
	@Query("SELECT p FROM Product p WHERE p.name = ?1")
	Product findProductByName(String name);
	
}