package com.wipro.estore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.estore.model.Product;
import com.wipro.estore.model.Register;

public interface RegisterRepository extends JpaRepository<Register, String>{

}
