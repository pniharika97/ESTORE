package com.wipro.estore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
@Component
public class AddCartBean {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;

@Column	
String username;

@Column
int Quantity;
@Column
double subtotal;

@Column
String name;

@Column
double price;
	
public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public double getPrice() {
	return price;
}

public void setPrice(double price) {
	this.price = price;
}

	public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public double getSubtotal() {
	return subtotal;
}

public void setSubtotal(double subtotal) {
	this.subtotal = subtotal;
}
public AddCartBean() {
	
}

public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public int getQuantity() {
	return Quantity;
}
public void setQuantity(int quantity) {
	Quantity = quantity;
}

}
