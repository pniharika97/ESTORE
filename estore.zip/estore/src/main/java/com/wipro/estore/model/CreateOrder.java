package com.wipro.estore.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

@Entity
public class CreateOrder {

	@Id
	int addressId;
	
	String userName;

	@Pattern(regexp="^[a-zA-Z0-9]+$",message = "Invalid Data")
	@Length(min=5,message = "Invalid Data")
	String name;
	
	@Pattern(regexp="^[a-zA-Z0-9]+$",message = "Invalid Data")
	@Length(min=5,message = "Invalid Data")
	String address;

	@Pattern(regexp="^[a-zA-Z0-9]+$",message = "Invalid Data")
	@Length(min=5,message = "Invalid Data")
	String city;
	
	@Pattern(regexp="^[a-zA-Z0-9]+$",message = "Invalid Data")
	@Length(min=5,message = "Invalid Data")
	String country;
	
	@Range(min = 10000, max = 999999, message = "Invalid Data")
	long pincode;
	
	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public CreateOrder() {
		
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	
}
