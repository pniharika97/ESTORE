package com.wipro.estore.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class InvoiceBean {

	@Id
	String invoiceId;
	
	String username;
	int itemsPurchased;


	double invoicedAmount;
	
	public double getInvoicedAmount() {
		return invoicedAmount;
	}

	public void setInvoicedAmount(double invoicedAmount) {
		this.invoicedAmount = invoicedAmount;
	}	
	public String getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getItemsPurchased() {
		return itemsPurchased;
	}

	public void setItemsPurchased(int itemsPurchased) {
		this.itemsPurchased = itemsPurchased;
	}

	public InvoiceBean() {
		
	}
	
}
