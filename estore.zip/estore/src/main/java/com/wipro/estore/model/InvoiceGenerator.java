package com.wipro.estore.model;

public class InvoiceGenerator {

	static String invoice="INV-";
     static int count=0;
    
     public static String getInvoice() {
    	 ++count;
    	 return invoice+""+String.valueOf(count);  
    }
     
     
}
