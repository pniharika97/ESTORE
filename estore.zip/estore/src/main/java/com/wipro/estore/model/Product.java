package com.wipro.estore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

@Entity
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	long productID;

	@Length(min = 5, message = "Invalid Data")
	@NotBlank(message = "Invalid Data")
	@Column(name = "NAME", length = 15, nullable = false, unique = false)
	String name;
	
	@Column(name = "PRODUCT_DESC", length = 50, nullable = true, unique = false)
	String description;

	@Range(min = 1, max = 9999, message = "Invalid Data")
	double price;

	public Product() {
	}

	public long getProductID() {
		return productID;
	}

	public void setProductID(long productID) {
		this.productID = productID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
