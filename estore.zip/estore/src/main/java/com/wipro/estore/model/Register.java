package com.wipro.estore.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;

@Entity
public class Register {
   
	@Id
	@Length(min = 3, max = 8, message = "Invalid Data")
	@Pattern(regexp="[A-Za-z0-9]+$",message = "Invalid Data")
	String userName;
	@Email(message = "Invalid Data")
	String email;
	@Length(min = 3, max = 8, message = "Invalid Data")
	String password;
	@Length(min = 3, max = 8, message = "Invalid Data")
	String confirmPassword;
	
	
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public Register() {
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
